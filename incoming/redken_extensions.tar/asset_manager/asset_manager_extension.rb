# Uncomment this if you reference any of your controllers in activate
# require_dependency 'application'

class AssetManagerExtension < Radiant::Extension
  version "0.1"
  description "A full-featured asset manager"
  url "http://code.digitalpulp.com"
  
  define_routes do |map|
    map.with_options :conditions => { :site => "Consumer" } do |c|
      c.resource :mass_upload, :path_prefix => "/admin/assets"
      c.resource :zip_upload, :path_prefix => "/admin/assets"
      c.resources :fck_assets, :path_prefix => "/admin"
      c.resources :assets, :path_prefix => "/admin"
    end
  end
  
  def activate
    require 'mime/types'
    require 'zip/zipfilesystem'
  end
  
  def deactivate
  end
  
end
