require File.dirname(__FILE__) + '/../test_helper'

# Re-raise errors caught by the controller.
MassUploadController.class_eval { def rescue_action(e) raise e end }

class MassUploadControllerTest < Test::Unit::TestCase
  fixtures :assets
  test_helper :login, :difference

  def setup
    @controller = MassUploadController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
    @host = @request.host = sites(:consumer).base_domain
    login_as :existing
  end

  def test_should_require_login_for_all_actions 
    logout
    assert_requires_login { get :new }
    assert_requires_login { get :edit }
    assert_requires_login { post :create }
    assert_requires_login { put :update }
  end
  
  def test_new_should_display_upload_form
    get :new
    assert_response :success
    assert_tag :form, :attributes => {:action => "/admin/assets/mass_upload", :method => "post"}
    5.times do |i|
      assert_tag :input, :attributes => {:type => "file", :name => "assets[#{i}][uploaded_data]" }
    end
  end
  
  def test_create_should_create_multiple_assets_and_redirect
    assert_difference Asset, :count, 2 do
      post :create, :assets => {
          0 => {:uploaded_data => file_upload("book.png", "image/png")}, 
          1 => {:uploaded_data => file_upload("assets.yml", "text/x-yaml")}}
      assert_response :redirect
      assert_redirected_to :controller => "mass_upload", :action => "edit"
      assert_not_empty assigns(:assets)
      assert_not_nil session[:assets]
      assert_not_empty session[:assets]
      assert_empty assigns(:failed)
    end
  end
  
  def test_create_should_flash_error_and_redirect_when_all_empty
    assert_no_difference Asset, :count do
      post :create, :assets => { 0 => {:uploaded_data => nil}, 1 => {:uploaded_data => nil}}
      assert_response :redirect
      assert_redirected_to :controller => "mass_upload", :action => "new"
      assert_not_nil flash[:error]
    end
  end
  
  def test_create_should_flash_error_and_redirect_when_all_failed
    assert_no_difference Asset, :count do
      post :create, :assets => {
          0 => {:uploaded_data => file_upload("book.png", nil)}, 
          1 => {:uploaded_data => file_upload("assets.yml", nil)}}
      assert_response :redirect
      assert_redirected_to :controller => "mass_upload", :action => "new"
      assert_not_nil flash[:error]
    end
  end
  
  def test_create_should_store_valid_assets_and_warn_when_some_failed
    assert_difference Asset, :count, 1 do
      post :create, :assets => {
          0 => {:uploaded_data => file_upload("book.png", "image/png")}, 
          1 => {:uploaded_data => file_upload("assets.yml", nil)}}
      assert_response :redirect
      assert_redirected_to :controller => "mass_upload", :action => "edit"
      assert_not_nil flash[:warning]
    end    
  end
  
  def test_create_should_store_valid_assets_and_redirect_when_some_empty
    assert_difference Asset, :count, 1 do
      post :create, :assets => {
          0 => {:uploaded_data => file_upload("book.png", "image/png")}, 
          1 => {:uploaded_data => nil}}
      assert_response :redirect
      assert_redirected_to :controller => "mass_upload", :action => "edit"
      assert_nil flash[:warning]
    end
  end
  
  def test_edit_should_load_multiple_assets_and_render_them_in_a_form
    @request.session[:assets] = [1, 2]
    get :edit
    assert_response :success
    assert_not_nil assigns(:assets)
    assert_not_empty assigns(:assets)
    assert_equal [1, 2], assigns(:assets).map(&:id)
    assigns(:assets).each do |asset|
      assert_tag :textarea, :attributes => {:name => "assets[#{asset.id}][description]"}
      assert_tag :select, :attributes => {:name => /#{asset.id}..expires_on/}
    end
  end
  
  def test_update_should_update_multiple_assets_and_redirect
    put :update, :assets => {
      1 => {:description => "Test"}, 
      2 => {:description => "Test 2"}}
    assert_response :redirect
    assert_redirected_to :controller => "mass_upload", :action => "new"
    assert_not_nil flash[:notice]
    assert_equal "Test", Asset.find(1).description
    assert_equal "Test 2", Asset.find(2).description
  end
end
