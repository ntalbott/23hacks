require File.dirname(__FILE__) + '/../test_helper'

# Re-raise errors caught by the controller.
ZipUploadController.class_eval { def rescue_action(e) raise e end }

class ZipUploadControllerTest < Test::Unit::TestCase
  fixtures :assets, :sites
  test_helper :login, :difference

  def setup
    @controller = ZipUploadController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
    @host = @request.host = sites(:consumer).base_domain
    login_as :existing
  end

  def test_should_require_login_for_all_actions 
    logout
    assert_requires_login { post :create }
  end
  
  def test_create_should_create_assets_and_redirect
    assert_difference Asset, :count, 3 do
      post :create, :upload => { :uploaded_data => file_upload('testdata.zip', nil) } 
    end
    assert_redirected_to edit_mass_upload_path
    assert_equal 3, assigns(:assets).size
  end
  
  def test_reports_failures
    Asset.any_instance.stubs(:valid?).returns(false)
    post :create, :upload => { :uploaded_data => file_upload('testdata.zip', nil) } 
    assert !assigns(:failed).empty?
    assert_redirected_to new_mass_upload_path
  end
end
