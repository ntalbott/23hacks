require File.dirname(__FILE__) + '/../test_helper'

class AssetTest < Test::Unit::TestCase
  fixtures :assets, :pages, :page_parts
  
  def setup
    @asset = Asset.new
  end

  def test_find_expired
    @expired = Asset.find_expired
    assert_included @expired, assets(:expired)
    assert_not_included @expired, assets(:png)
    assert_not_included @expired, assets(:qt)
  end

  def test_search_should_find_assets_via_description_and_filename
    assert_equal [assets(:png)], Asset.search("image")
    assert_equal [assets(:png)], Asset.search("mypng")
    assert_equal [assets(:qt)], Asset.search("movie")
    assert_equal [assets(:expired), assets(:qt)], Asset.search("video")
  end

  def test_find_all_by_index
    assert_equal [assets(:png)], Asset.find_all_by_index('m')
    assert_equal [assets(:qt)], Asset.find_all_by_index('v')
    assert_equal [assets(:expired)], Asset.find_all_by_index('a')
    (("a".."z").to_a - ['a', 'm', 'v'] + ["#"]).each do |letter|
      assert_equal [], Asset.find_all_by_index(letter)
    end
    assert_equal Asset.find(:all, :order => 'filename'), Asset.find_all_by_index
  end

  def test_find_all_by_type
    assert_equal [assets(:png)], Asset.find_all_by_type("image")
    assert_equal [assets(:expired), assets(:qt)], Asset.find_all_by_type("video")
    assert_equal [], Asset.find_all_by_type("audio")
    assert_equal [], Asset.find_all_by_type("flash")
  end
  
  def test_should_save_to_filesystem
    assert_equal :file_system, Asset.attachment_options[:storage]
    assert_equal "public/assets/files", Asset.attachment_options[:path_prefix]
  end
  
  def test_should_be_flash_when_content_type_is_flash
    @asset.content_type = "application/x-shockwave-flash"
    assert @asset.flash?
  end
  
  def test_should_be_video_when_content_type_is_video
    @asset.content_type = "video/quicktime"
    assert @asset.video?
    
    @asset.content_type = "video/mpeg"
    assert @asset.video?
  end
  
  def test_should_be_image_when_content_type_is_image
    @asset.content_type = "image/png"
    assert @asset.image?
    
    @asset.content_type = "image/tiff"
    assert @asset.image?
  end
  
  def test_should_be_audio_when_content_type_is_audio
    @asset.content_type = "audio/wav"
    assert @asset.audio?
    
    @asset.content_type = "audio/mpeg"
    assert @asset.audio?
  end

  def test_used_in_should_return_pages_that_contain_the_asset
    assert_equal [pages(:homepage), pages(:documentation)], assets(:png).used_in.sort_by(&:id)
  end
  
  def test_find_by_path
    assert_equal assets(:png), Asset.find_by_path("/system/assets/files/0000/0001/mypng.png")
  end
  
  def test_customized_error_message
    @asset.size = 300.megabytes
    assert !@asset.valid?
    assert_no_match /included/, @asset.errors.on(:size).to_s
    assert_match /must be less than/, @asset.errors.on(:size).to_s
  end
  
  def test_should_not_rename_when_uploading_new_file_to_existing_asset
    asset = assets(:png)
    asset.uploaded_data = file_upload('book.png', 'image/png')
    assert_equal 'mypng.png', asset.filename
  end
  
  def test_should_change_created_at_when_uploading_new_file_to_existing_asset
    asset = assets(:png)
    old_created_at = asset.created_at
    asset.uploaded_data = file_upload('book.png', 'image/png')
    assert_not_equal old_created_at, asset.created_at
  end
  
  def test_should_require_new_file_to_be_same_content_type
    asset = assets(:png)
    asset.uploaded_data = file_upload('assets.yml', 'text/x-yaml')
    
    assert !asset.valid?
    assert_not_nil asset.errors.on(:content_type)
  end
  
  def test_should_create_asset_from_filesystem
    asset = Asset.new(:local_data => File.open(File.join(File.dirname(__FILE__), '..', 'fixtures', 'book.png')))
    assert asset.valid?
  end
  
  def test_should_extract_files_from_string_io
    tmp = StringIO.new(File.open(File.join(File.dirname(__FILE__), '..', 'fixtures', 'testdata.zip')).read)
    files = []
    Asset.extracted_from(:uploaded_data => tmp) do |f|
      files << File.basename(f.path)
    end
    assert_equal %w(file_one.txt file_two.txt img.gif), files
  end
  
  def test_should_extract_files_from_tempfile
    file = File.open(File.join(File.dirname(__FILE__), '..', 'fixtures', 'testdata.zip'))
    tmp = Tempfile.new('extract_tempfile')
    while not file.eof? 
      tmp.write file.read
    end
    tmp.close

    files = []
    Asset.extracted_from(:uploaded_data => tmp) do |f|
      files << File.basename(f.path)
    end
    assert_equal %w(file_one.txt file_two.txt img.gif), files.sort
  end
end
