class Asset < ActiveRecord::Base
  FLASH = %w{application/x-shockwave-flash}
  VIDEO = %w{video/x-flv video/mpeg video/msvideo video/quicktime}
  AUDIO = %w{audio/mpeg audio/mpeg3 audio/x-mpeg-3 }
  PDF   = %w{application/pdf}
  DOC   = %w{application/msword}
  PPT   = %w{application/vnd.ms-powerpoint application/mspowerpoint application/powerpoint application/x-mspowerpoint}
  XLS   = %w{application/excel application/msexcel application/x-msexcel application/x-ms-excel application/vnd.ms-excel application/x-excel application/x-dos_ms_excel application/xls application/x-xls zz-application/zz-winassoc-xls}
  
  # mime-types might not be active on redken.pd or the live site. 
  # double-check the FLV and XLS mime-types, as they don't seem standard with apache

  TYPES = [:images, :pdf, :flash, :video, :audio, :doc, :ppt, :xls]

  SEARCH_FIELDS = [:description, :filename]

  EXPIRATION_LOOKAHEAD = 30.days

  has_attachment :storage => :file_system, 
                 :path_prefix => "public/assets/files",
                 :max_size => 200.megabytes
  validates_as_attachment
  validate_on_update :cannot_change_content_type
  
  cattr_accessor :per_page
  @@per_page = 50
    
  order_by "created_at DESC"
  
  class << self
    def search(query, page = 1)
      terms = query.strip.split(/\s/).reject(&:blank?).map {|s| s.downcase.strip }
      conditions, values = [], []
      like = proc {|field| "LOWER(#{field}) LIKE ?"}
      wrap = proc {|value| "%#{value}%"}
      terms.each do |term|
        conditions << "(" + SEARCH_FIELDS.map(&like).join(" OR ") + ")"
        values << ([term] * SEARCH_FIELDS.size).map(&wrap)
      end
      paginate :conditions => [conditions.join(" AND "), values].flatten, :page => page, :order => 'filename'
    end
    
    def find_all_by_index(first_letter = "", page = 1)
      if first_letter =~ /^[^a-z]$/i
        conditions = ("a".."z").map {|num| "LOWER(filename) NOT LIKE ?" }
        values = ("a".."z").map {|char| "#{char}%"}
        conditions = [conditions.join(" AND "), values].flatten
      elsif first_letter =~ /^[a-z]$/i
        conditions = ["LOWER(filename) LIKE ?", "#{first_letter.downcase}%"]
      else
        conditions = nil
      end
      paginate :conditions => conditions, :page => page, :order => 'filename'
    end
    
    def find_all_by_type(type, page = 1)
      case type
        when /image/
          conditions = ["content_type LIKE ?", "image%"]
        when /video/
          conditions = ["content_type LIKE ? OR content_type IN (?)", "video%", VIDEO]
        when /flash/
          conditions = ["content_type IN (?)", FLASH]
        when /audio/
          conditions = ["content_type LIKE ? OR content_type IN (?)", "audio%", AUDIO]
        when /pdf/
          conditions = ["content_type IN (?)", PDF]
        when /doc/
          conditions = ["content_type IN (?)", DOC]
        when /ppt/
          conditions = ["content_type IN (?)", PPT]
        when /xls/
          conditions = ["content_type IN (?)", XLS]
        else
          conditions = nil
      end
      paginate :conditions => conditions, :page => page, :order => 'filename'
    end
    
    def find_expired(page = 1)
      paginate :conditions => ["expires_on IS NOT NULL AND expires_on <= ?", EXPIRATION_LOOKAHEAD.from_now.to_s(:db)], :page => page, :order => 'expires_on'
    end
    
    def find_by_path(path)
      # Pull out the id from the path
      id = path.split('/').select {|d| d =~ /^\d+$/ }.join.to_i
      find(id)
    end
    
    def inclusion_error_messages
      {
        :size => "must be less than 200 megabytes",
        :content_type => "must be valid"
      }
    end
    
    def extracted_from(archive, &block)
      path =  case archive[:uploaded_data]
              when StringIO # Write tempfile since rubyzip doesn't seem to like StringIO objects
                temp = Tempfile.new(archive[:uploaded_data].object_id)
                while not archive[:uploaded_data].eof? 
                  temp.write archive[:uploaded_data].read
                end
                temp.close
                temp.path
              when Tempfile, ActionController::TestUploadedFile # for testing
                archive[:uploaded_data].path
              else
                raise TypeError, "Expected a StringIO or Tempfile"
              end
      
      Zip::ZipFile.open(path) do |zip|
        zip.each do |file|
          next if (base = File.basename(file.name)) =~ %r(^\.) || !file.file?
          tempfile = File.join(RAILS_ROOT, 'tmp', 'attachment_fu', base)
          begin
            file.extract(tempfile)
            yield File.open(tempfile)
          rescue Zip::ZipError
            next
          ensure
            FileUtils.rm_rf(tempfile) if File.exists?(tempfile)
          end
        end
      end
    end
  end
  
  def flash?
    FLASH.include?(self.content_type)
  end
  
  def video?
    self.content_type =~ /^video/ || VIDEO.include?(self.content_type)
    # for this to work in the first place the mime-type needs to be set in apache magic. (see line 10)
    # there is also an issue with firefox uploads being set to mime type 'application/force-download',
    # which leads to pdf's and flv's not being uploaded as the right file type. this needs some research.
    # alternatively, take the quick/dirty method to check the file extension:
    #    || self.filename =~ /^.*\.pdf$/i     ...   just tack that on the end
  end
  
  def image?
    super || self.content_type =~ /^image/
  end
  
  def audio?
    self.content_type =~ /^audio/ || AUDIO.include?(self.content_type)
  end

  def pdf?
    PDF.include?(self.content_type)
    # see above comments (line 134) concerning firefox uploads
  end
  
  def doc?
    self.content_type =~ /^doc/ || DOC.include?(self.content_type)
  end
  
  def ppt?
    self.content_type =~ /^ppt/ || PPT.include?(self.content_type)
  end
  
  def xls?
    self.content_type =~ /^xls/ || XLS.include?(self.content_type)
    # see above comments (line 10) about excel mime types.
  end
    
  def used_in
    @used_in ||= Page.find(:all, :include => :parts, :conditions => ["page_parts.content LIKE ?", "%#{self.public_filename}%"])
  end

  def expired?
    self.expires_on <= Date.today
  end

  def expiring_soon?
    self.expires_on <= EXPIRATION_LOOKAHEAD.from_now.to_date
  end

  def uploaded_data=(value)
    self.created_at = Time.now
    super
  end

  def filename=(value)
    super if new_record?
  end

  def content_type=(value)
    @old_content_type = self.content_type unless new_record?
    super
  end
  
  def local_data=(file_data)
    return nil if file_data.nil? || file_data.stat.size == 0 
    self.size         = file_data.stat.size
    self.filename     = file_data.path
    self.content_type = MIME::Types.type_for(filename).first.to_s
    self.temp_path    = file_data.path
  end

  private
    def attachment_attributes_valid?
      [:size, :content_type].each do |attr_name|
        enum = attachment_options[attr_name]
        errors.add attr_name, self.class.inclusion_error_messages[attr_name] unless enum.nil? || send(attr_name).blank? || enum.include?(send(attr_name))
      end
    end
    
    def cannot_change_content_type
      if @old_content_type && @old_content_type != content_type
        errors.add :content_type, "must be the same as the original file when replacing"
      end
    end
end
