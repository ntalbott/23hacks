module MassUploadHelper
  include AssetsHelper
end
