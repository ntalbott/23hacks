module AssetsHelper

  def expiration_date(asset)
    asset.expires_on.blank? ? "Does not expire" : asset.expires_on.strftime("%b %d, %Y")
  end
  
  def just_created
    yield if params[:just_created]
  end
  
  def dimensions(asset)
    "#{asset.width} x #{asset.height}"
  end
  
  def asset_class(asset)
    case
      when asset.video?
        "asset-video"
      when asset.audio?
        "asset-audio"
      when asset.flash?
        "asset-flash"
      when asset.image?
        "asset-image"
      when asset.pdf?
        "asset-pdf"
      when asset.doc?
        "asset-doc"
      when asset.ppt?
        "asset-ppt"
      when asset.xls?
        "asset-xls"
      else
        "asset-generic"
    end
  end

  def asset_icon(asset)
    case
      when asset.video?
        "/images/admin/icon.file.video.l.gif"
      when asset.audio?
        "/images/admin/icon.file.audio.l.gif"
      when asset.flash?
        "/images/admin/icon.file.flash.l.gif"
      when asset.image?
        "/images/admin/icon.file.image.l.gif"
      when asset.pdf?
        "/images/admin/icon.file.pdf.l.gif"
      when asset.doc?
        "/images/admin/icon.file.doc.l.gif"
      when asset.ppt?
        "/images/admin/icon.file.ppt.l.gif"
      when asset.xls?
        "/images/admin/icon.file.xls.l.gif"
      else
        "/images/admin/icon.file.generic.l.gif"
    end
  end

  def asset_expire_class(asset)
    if asset.expired?
      "expired"
    elsif asset.expiring_soon?
      "expiring-soon"
    end
  end

end
