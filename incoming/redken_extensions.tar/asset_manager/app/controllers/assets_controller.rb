class AssetsController < ApplicationController
  # A hack, but the only way it works in something other than dev mode
  write_inheritable_attribute :resourceful_callbacks, {}
  write_inheritable_attribute :resourceful_responses, {}
  write_inheritable_attribute :parents,               []

  helper :redken

  make_resourceful do
    actions :all
    
    response_for :create do |format|
      format.html do
        redirect_to hash_for_edit_asset_path(:id => current_object).merge(:just_created => 1)
      end
    end
    
    response_for :destroy do |format|
      format.html do
        redirect_to(params[:undo] ? new_asset_path : assets_path)
      end
    end
    
    response_for :update do |format|
      format.html do
        if params[:commit] !~ /metadata/i
          redirect_to edit_asset_path(current_object)
        else
          redirect_to objects_path
        end
      end
    end
    
    response_for :update_fails do |format|
      format.html do
        flash[:error] = "There was a problem saving: <strong>#{current_object.errors.full_messages.to_sentence}</strong>"
        if params[:commit] !~ /metadata/i
          redirect_to asset_path(current_object)
        else
          render :action => :edit, :status => 422
        end
      end
    end
  end
  
  before_filter do |c|
    c.include_stylesheet 'asset_manager'
    c.include_javascript 'prototype_extensions'
    c.include_javascript 'redken'
  end

  def current_objects
    @current_objects ||= case
      when params[:search]
        current_model.search(params[:search], params[:page])
      when (params[:tab] == "browse") && params[:index]
        current_model.find_all_by_index(params[:index], params[:page])
      when (params[:tab] == "browse") && params[:type]
        current_model.find_all_by_type(params[:type], params[:page])
      when (params[:tab] == "browse")
        current_model.paginate(:include => model_includes, :page => params[:page], :order => 'filename')
      when (params[:tab] == "report")
        current_model.find_expired(params[:page])
      else
        current_model.paginate(:include => model_includes, :page => params[:page], :order => 'created_at DESC')
    end
  end

end
