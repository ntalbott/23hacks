class MassUploadController < ApplicationController

  include AssetManager::MassAnnouncements

  before_filter do |c|
    c.include_stylesheet "asset_manager"
    c.include_javascript 'prototype_extensions'
    c.include_javascript 'redken'
  end

  helper :redken, :assets

  def new
    session[:assets] = nil
  end
  
  def create
    @assets = []
    @failed = []
    order_and_extract(params[:assets]).each do |attrs|
      asset = Asset.new(attrs)
      if asset.save
        @assets << asset
      else
        @failed << asset
      end
    end
    if @assets.empty?
      @failed.all? {|f| f.filename.blank? } ? announce_nothing_uploaded : announce_all_failed
      redirect_to :action => "new"
    else
      session[:assets] = @assets.map(&:id)
      announce_some_failed unless @failed.all?{|f| f.filename.blank? }
      redirect_to :action => "edit"
    end
  end
  
  def edit
    @assets = Asset.find(session[:assets])
  end
  
  def update
    params[:assets].each do |k,v|
      asset = Asset.find(k)
      asset.update_attributes(v)
    end
    announce_multiple_updated
    session[:assets] = nil
    redirect_to new_mass_upload_path
  end
  
  private
  
    def order_and_extract(hash)
      hash.to_a.sort_by(&:first).map(&:last)
    end
    
end
