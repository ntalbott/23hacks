class ZipUploadController < ApplicationController

  include AssetManager::MassAnnouncements
  
  before_filter do |c|
    c.include_stylesheet "asset_manager"
    c.include_javascript 'prototype_extensions'
    c.include_javascript 'redken'
  end

  helper :redken, :assets
  
  def create
    session[:assets] = nil
    @assets, @failed = [], []

    Asset.extracted_from(params[:upload]) do |i|
      asset = Asset.new(:local_data => i)
      (asset.save ? @assets : @failed) << asset
    end

    if @assets.empty?
      announce_all_failed
      redirect_to new_mass_upload_path
    else
      session[:assets] = @assets.map(&:id)
      announce_some_failed unless @failed.all? { |f| f.filename.blank? }
      redirect_to edit_mass_upload_path
    end
    
  rescue TypeError, Zip::ZipError
    flash[:error] = "There was an error unzipping the file, or this is not a valid .zip archive. Please choose another file."
    redirect_to new_mass_upload_path
  end
  
end
