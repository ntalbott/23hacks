class FckPagesController < ApplicationController

  layout 'application_popup'
  
  def index
    if params[:root] # If a root page is specified
      @homepage = Page.find(params[:root])
      @site = @homepage.root.site
    elsif @site = Site.find(:first, :order => "position ASC")  # If there is a site defined
      @homepage = @site.homepage
    end
    @homepage ||= Page.find_by_parent_id_and_draft_of(nil, nil)
  end
  
  def search
    @query = params[:q].to_s
    @site = Site.find(params[:site]) rescue nil
    @pages = Page.search(@query).reject do |p|
      @site && p.root != @site.homepage
    end
  end
end
