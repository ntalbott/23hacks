# Uncomment this if you reference any of your controllers in activate
# require_dependency 'application'

class FckShardsExtension < Radiant::Extension
  version "0.1"
  description "Adds FCKeditor to text areas in the page edit screen."
  url "http://code.digitalpulp.com"

  define_routes do |map|
    map.with_options :controller => "fck_pages", :conditions => { :site => "Consumer" } do |fck|
      fck.fck_pages '/admin/fck_pages', :action => "index"
      fck.fck_pages_search '/admin/fck_pages/search', :action => "search"
    end
  end
  
  def activate
    admin.page.edit.add :main, "fck_editor", :before => "edit_header"
  end
  
  def deactivate
  end
  
end
