var RadiantFCK = Behavior.create({
  initialize: function(){
    this.parent = this.element.up('div');
    if(RadiantFCK.enabled)
      this.createEditor.apply(this, arguments);
  },
  createEditor: function(){
		var config_name = arguments[0] ? "." + arguments[0] : "";
    this.editor = new FCKeditor(this.element.id, arguments[1], arguments[2], arguments[3]);
    this.editor.BasePath = '/javascripts/fckeditor/';
    this.editor.Config['CustomConfigurationsPath'] = '../../fckeditor_custom.js';
    this.editor.Config['EditorAreaCSS'] = "/stylesheets/fckeditor" + config_name + ".css";
    this.editor.Config['TemplatesXmlPath'] = "/javascripts/fckeditor_templates" + config_name + ".xml";
    // this.editor.Config['StylesXmlPath'] = "/javascripts/fckeditor_styles" + config_name + ".xml";
    this.editor.Config['StylesXmlPath'] = "/javascripts/fckeditor_styles.xml";
    this.editor.Config['LinkBrowserURL'] = RadiantFCK.LinkBrowserURL;
    this.editor.ReplaceTextarea();
    this.frame = $(this.element.id + '___Frame');
    this.config = $(this.element.id + '___Config');
  },
  destroyEditor: function(){
    var api = FCKeditorAPI.GetInstance(this.element.id);
    if(api) {
        api.UpdateLinkedField();
    }
    this.parent.select('iframe').invoke('remove');
    this.frame = null;
    this.config.remove();
    this.config = null;
    this.editor = null;
    this.element.show();
  }
});


RadiantFCK.toggle = function(){ 
  if(this.enabled)
    this.instances.invoke('destroyEditor');
  else
    this.instances.invoke('createEditor');
  this.enabled = !this.enabled;
};

RadiantFCK.enabled = true;
Event.addBehavior({
  'TEXTAREA.textarea': RadiantFCK,

  'TEXTAREA.wysiwyg-generic-content' : RadiantFCK("generic-content", /* 640 */ "100%", "500", "RedkenStandard"),
  'TEXTAREA.wysiwyg-article-content' : RadiantFCK("article-content", /* 720 */ "100%", "500", "RedkenStandard"),
  'TEXTAREA.wysiwyg-article-sidebar' : RadiantFCK("article-sidebar", /* 350 */ "100%", "400", "RedkenStandard"),
  'TEXTAREA.wysiwyg-inline-content'  : RadiantFCK("inline-content",  "100%", "300", "RedkenBasic"),

	// NOTE: these WYSIWYG boxes contain fixed-height content.
	// 92px = three-row toolbar
	// 16px = BODY padding
	// 16px = scrollbar
  'TEXTAREA.wysiwyg-main-feature'    : RadiantFCK("main-feature",    /* 907 + 16 + 16 */ "100%", 420 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-supp-feature-1'  : RadiantFCK("supp-feature-1",  /* 867 + 16 + 16 */ "100%", 200 + 24 + 16 + 92, "RedkenStandard"), // 24px accounts for header height
  'TEXTAREA.wysiwyg-supp-feature-2'  : RadiantFCK("supp-feature-2",  /* 415 + 16 + 16 */ "100%", 300 + 24 + 16 + 92, "RedkenStandard"), // 24px accounts for header height
  'TEXTAREA.wysiwyg-supp-feature-3'  : RadiantFCK("supp-feature-3",  /* 270 + 16 + 16 */ "100%", 200 + 24 + 16 + 92, "RedkenStandard"), // 24px accounts for header height; FIXME: height needs verification
  'TEXTAREA.wysiwyg-pro-homepage-left'   : RadiantFCK("pro-homepage-left",   /* 446 + 16 + 16 */ "100%", 400 + 24 + 16 + 92, "RedkenStandard"), // 24px accounts for header height
  'TEXTAREA.wysiwyg-pro-homepage-right'   : RadiantFCK("pro-homepage-right",   /* 218 + 16 + 16 */ "100%", 400 + 24 + 16 + 92, "RedkenStandard"), // 24px accounts for header height

  'TEXTAREA.wysiwyg-catalog-page'    : RadiantFCK("catalog-page",    /* 720 + 16 + 16 */ "100%", 500 + 24 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-product-content' : RadiantFCK("product-content", /* 380 + 16 + 16 */ "100%", 150 + 24 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-product-trend'   : RadiantFCK("product-trend",   /* 470 + 16 + 16 */ "100%", 100 + 24 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-get-inspired'   : RadiantFCK("get-inspired",   /* 500 + 16 + 16 */ "100%", 400 + 24 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-hair-recommendation'   : RadiantFCK("hair-recommendation",   /* 500 + 16 + 16 */ "100%", 400 + 24 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-style-gallery'   : RadiantFCK("style-gallery",   /* 500 + 16 + 16 */ "100%", 400 + 24 + 16 + 92, "RedkenStandard"),
  'TEXTAREA.wysiwyg-previous-winner-feature'   : RadiantFCK("previous-winner-feature",   /* 500 + 16 + 16 */ "100%", 400 + 24 + 16 + 92, "RedkenStandard")
  
});

