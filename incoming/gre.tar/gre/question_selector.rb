require 'fileutils'
require 'yaml'

class QuestionSelector
  attr_accessor :issues, :arguments, :current_questions

  def initialize
    self.issues = YAML.load_file('issues.yml')
    self.arguments = YAML.load_file('arguments.yml')
    self.current_questions = []
  end
  
  def select_question(hash, prefix)
    question = hash['new'].delete( hash['new'].sort_by { rand }.first )
    hash['used'] ||= []
    hash['used'] << question
    current_questions << [prefix, question].join(" : ")
  end
  
  def select_round
    2.times { select_question(issues, "ISSUE") }
    select_question(arguments, "ARGUMENT")
  end
  
  def save_files
    File.open("issues.yml", "w") {|f| YAML.dump(self.issues, f)}
    File.open("arguments.yml", "w") {|f| YAML.dump(self.arguments, f)}
    FileUtils.rm "question.txt"
  end
  
  def take_questions
    select_round
    current_questions.each do |q|
      File.open("question.txt", "w") {|f| f.write word_wrap(q, 75) }
      system "lpr question.txt"
    end
    save_files
  end

  def word_wrap(text, line_width = 80)
    text.gsub(/\n/, "\n\n").gsub(/(.{1,#{line_width}})(\s+|$)/, "\\1\n").strip
  end
end

QuestionSelector.new.take_questions
